package com.example.propellerhealthassistant

import androidx.lifecycle.*
import com.example.propellerhealthassistant.data.HealthRepository
import com.example.propellerhealthassistent.model.Event
import com.example.propellerhealthassistent.model.Medication
import com.example.propellerhealthassistent.model.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HealthViewModel @Inject constructor(private val repository: HealthRepository): ViewModel() {

    val allEvents: LiveData<List<Event>> = repository.allEvents.asLiveData()
    val allMedication: LiveData<List<Medication>> = repository.allMedication.asLiveData()

    fun insert(event: Event) = viewModelScope.launch{
        repository.insert(event)
    }

    fun insertMedication(medication: Medication) = viewModelScope.launch{
        repository.insertMedication(medication)
    }

    fun insertUser(user: User) = viewModelScope.launch{
        repository.insertUser(user)
    }

}

