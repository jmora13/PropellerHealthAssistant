package com.example.propellerhealthassistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.viewModels
import androidx.annotation.Nullable
import androidx.appcompat.app.AppCompatActivity
import com.example.propellerhealthassistant.databinding.ActivityNewEventBinding
import com.example.propellerhealthassistent.model.Event
import com.example.propellerhealthassistent.model.Medication
import dagger.hilt.android.AndroidEntryPoint
import java.io.Serializable
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.*

@AndroidEntryPoint
class NewEventActivity : AppCompatActivity(), Serializable {
    private lateinit var binding: ActivityNewEventBinding
    private lateinit var spinner: Spinner
    private lateinit var datePicker: DatePicker
    private lateinit var timePicker: TimePicker
    override fun onCreate(savedInstanceState: Bundle?) { //ACTIVITY TO ADD EVENT
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_event)

        binding = ActivityNewEventBinding.inflate(layoutInflater)
        datePicker = findViewById(R.id.datePicker)
        timePicker = findViewById(R.id.timePicker)
        spinner = findViewById(R.id.spinner)


        ArrayAdapter.createFromResource( //INITIALIZE SPINNER
            this, R.array.medicine_types,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }

        val today = Calendar.getInstance()
        binding.datePicker.init(today.get(Calendar.YEAR), today.get(Calendar.MONTH), //CALENDAR PICKER INITIALIZED TO TODAYS DATE
            today.get(Calendar.DAY_OF_MONTH)
        ) { view, year, month, day ->
            val month = month + 1
            val msg = "You Selected: $day/$month/$year"
            Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
        }
    }

    fun saveEvent(view: View) { //SAVE VALUES PICKED IN NEW ACTIVITY
        val eventIntent = Intent()
        val type = spinner.selectedItem.toString()
        val year = datePicker.year
        val month = datePicker.month + 1
        val day = datePicker.dayOfMonth
        val localDate = LocalDate.of(year, month,day)
        val dtf: DateTimeFormatter = DateTimeFormatter.ofPattern("uuuu-MM-dd'T'")
        val date =  localDate.atStartOfDay().atOffset(ZoneOffset.UTC).format(dtf) //GET DATE FROM DATE PICKER
        val hour = timePicker.hour //GET TIME FROM TIME PICKER
        val min = timePicker.minute
        val time = "$hour:$min"



        var dateTime = date + time +":00.000Z" //MAKES 8601 FORMAT
        val event = Event( dateTime, 0, "", type!!, "" )
        eventIntent.putExtra("EVENT", event)
        setResult(Activity.RESULT_OK, eventIntent)
        Toast.makeText(this, "Saved Event",Toast.LENGTH_SHORT).show()
        finish()
    }
}
