package com.example.propellerhealthassistant.data

import com.example.propellerhealthassistent.model.Event
import com.example.propellerhealthassistent.model.Medication
import com.example.propellerhealthassistent.model.User
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HealthRepository @Inject constructor(private val healthDao: HealthDao) {

    val allEvents: Flow<List<Event>> = healthDao.getEvents()
    val allMedication: Flow<List<Medication>> = healthDao.getMedication()
    suspend fun insert(event: Event){
        healthDao.insert(event)
    }

    suspend fun insertMedication(medication: Medication){
        healthDao.insertMedication(medication)
    }

    suspend fun insertUser(user: User){
        healthDao.insertUser(user)
    }
}